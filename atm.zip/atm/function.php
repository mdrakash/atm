<?php 
include('db_config.php');
session_start();
	
    if(isset($_POST['enter_card'])){
		$card_no = $_POST['card_no'];

		$error = 0;
		if($card_no == ""){
			$error = $error + 1;
		}

		if($error == 0){
			$sql = "SELECT * FROM user WHERE card_no='$card_no'";
	        $connection = db_config::DBConnect();
			$resource_data = $connection->view($sql);
			$resource_obj = $resource_data->fetch_object();
		    if($resource_obj->card_no==$card_no){
				$_SESSION['card_no']=$resource_obj->card_no;
				$_SESSION['log']=true;
				header('location:t_login_input_pin.php');
		    }else{
                $_SESSION['cardError']="Incorrect card";
				header('location:index.php');
		    }
		}else{
			header('location:index.php');
		}
	}

	if(isset($_POST['confirmPin'])){
		$pin = $_POST['pin'];
		$card_no=$_SESSION['card_no'];
		$error = 0;
		if($pin == ""){
			$error = $error + 1;
		}

		if($error == 0){
			$sql = "SELECT * FROM user WHERE card_no='$card_no'";
	        $connection = db_config::DBConnect();
			$resource_data = $connection->view($sql);
			$resource_obj = $resource_data->fetch_object();
		    if($resource_obj->card_no==$card_no && $resource_obj->password==$pin){
				$_SESSION['card_no']=$resource_obj->card_no;
				$_SESSION['log']=true;
				header('location:t_account_account_details.php');
		    }else{
                $_SESSION['pinError']="Incorrect Pin";
				header('location:t_login_input_pin.php');
		    }
		}else{
			$_SESSION['pinError']="Insert Pin";
			header('location:t_login_input_pin.php');
		}
	}


	if(isset($_GET['logout'])){
		session_destroy();
		header('location:index.php');
	}
	if(isset($_GET['cash'])){
		$bal=$_GET['cash'];
		$error=0;
		if($bal == ""){
			$error = $error + 1;
		}
		if($error==0){
			$card_no=$_SESSION['card_no'];
			$sql = "SELECT * FROM user where card_no='$card_no'";
			$connection = db_config::DBConnect();
			$resource_data = $connection->view($sql);
			$resource_obj = $resource_data->fetch_object();
			$current_balance= $resource_obj->balance+$bal;
			$sql="UPDATE user set balance='$current_balance' WHERE card_no='$card_no'";
			$connection->insert($sql);
			$_SESSION['insert']="Balance Added";
			header('location:t_account_deposit_cash.php');

		}
		if($error==1){
			$_SESSION['insert']="Enter ammount";
			header('location:t_account_deposit_cash.php');
		}
	}

	if(isset($_GET['check'])){
		$bal=$_GET['check'];
		$error=0;
		if($bal == ""){
			$error = $error + 1;
		}
		if($error==0){
			$card_no=$_SESSION['card_no'];
			$sql = "SELECT * FROM user where card_no='$card_no'";
			$connection = db_config::DBConnect();
			$resource_data = $connection->view($sql);
			$resource_obj = $resource_data->fetch_object();
			$current_balance= $resource_obj->balance+$bal;
			$sql="UPDATE user set balance='$current_balance' WHERE card_no='$card_no'";
			$connection->insert($sql);
			$_SESSION['insert']="Balance Added";
			header('location:t_account_deposit_check.php');

		}
		if($error==1){
			$_SESSION['insert']="Enter ammount";
			header('location:t_account_deposit_check.php');
		}
	}

	if(isset($_POST['withdraw'])){
		$with=$_POST['with'];
		$error=0;
		if($with == ""){
			$error = $error + 1;
		}
		if($error==0){
			$card_no=$_SESSION['card_no'];
			$sql = "SELECT * FROM user where card_no='$card_no'";
			$connection = db_config::DBConnect();
			$resource_data = $connection->view($sql);
			$resource_obj = $resource_data->fetch_object();
			if($current_balance= $resource_obj->balance<$with){
				$_SESSION['lowbal']="insufficient balance";
				header('location:t_account_withdrawl.php');
			}else{
			$current_balance= $resource_obj->balance-$with;
			$sql="UPDATE user set balance='$current_balance' WHERE card_no='$card_no'";
			$connection->insert($sql);
			// $_SESSION['wmsg']="Add succsessfully";
			 header('location:t_account_account_details.php');
		}

		}
		if($error==1){
			// $_SESSION['wmsg']="Enter ammount";
			 header('location:t_account_account_details.php');
		}
	}

	if(isset($_POST['transfer'])){
		$accfrom=$_POST['accfrom'];
		$accto=$_POST['accto'];
		$ammount=$_POST['ammount'];
		$error=0;
		if($accto == ""){
			$error = $error + 1;
		}
		if($accfrom == ""){
			$error = $error + 1;
		}if($accfrom ==$accto){
			$error = $error + 1;
		}
		if($ammount == ""){
			$error = $error + 1;
		}
		if($error==0){
			$sql = "SELECT * FROM user where card_no='$accfrom'";
			$connection = db_config::DBConnect();
			$resource_data = $connection->view($sql);
			$resource_obj = $resource_data->fetch_object();
			$current_balance= $resource_obj->balance;
			if($current_balance>$ammount){
				$afb=$current_balance-$ammount;
				$sql="UPDATE user set balance='$afb' WHERE card_no='$accfrom'";
				$connection->insert($sql);
				$sql = "SELECT * FROM user where card_no='$accto'";
				$connection = db_config::DBConnect();
				$resource_data = $connection->view($sql);
				$resource_obj = $resource_data->fetch_object();
				$acto= $resource_obj->balance+$ammount;
				$sql="UPDATE user set balance='$acto' WHERE card_no='$accto'";
				$connection->insert($sql);
				header('location:t_account_account_details.php');
			}
			else{
				$_SESSION['low']="Insufficient Balance";
				header('location:t_account_transfer_funds.php');
			}
		}
		else{
			$_SESSION['Invalid']="Invalid Account OR Ammount";
			header('location:t_account_transfer_funds.php');
		}
	}
?>