<?php 
  include('header.php');
?>
<div class="row">
    <div class="col-xs-8 cst" id="screenView">
        <!-- Place <h1></h1> below -->

        <!-- Replace Video with Animated Gif or Animated SVG -->
        <div class="row">
            <div class="col-lg-12 text-center" style="border-right:solid 3px #CCC">
                <h1 class="demo-section-title text-uppercase text-center">Input Your Pin Number</h1>
                <form action="function.php" method="post">
                    <input autocomplete="off" type="password" name="pin" id="userPinInput" value="" class="form-control" />

                    <!-- TABLE -->
                    <div id="pinPad">
                        <table>
                            <tr>
                                <td><a id="btn1" href="#" class="btn btn-block btn-lg btn-inverse">1</a></td>
                                <td><a id="btn2" href="#" class="btn btn-block btn-lg btn-inverse">2</a></td>
                                <td><a id="btn3" href="#" class="btn btn-block btn-lg btn-inverse">3</a></td>
                            </tr>
                            <tr>
                                <td><a id="btn4" href="#" class="btn btn-block btn-lg btn-inverse">4</a></td>
                                <td><a id="btn5" href="#" class="btn btn-block btn-lg btn-inverse">5</a></td>
                                <td><a id="btn6" href="#" class="btn btn-block btn-lg btn-inverse">6</a></td>
                            </tr>
                            <tr>
                                <td><a id="btn7" href="#" class="btn btn-block btn-lg btn-inverse">7</a></td>
                                <td><a id="btn8" href="#" class="btn btn-block btn-lg btn-inverse">8</a></td>
                                <td><a id="btn9" href="#" class="btn btn-block btn-lg btn-inverse">9</a></td>
                            </tr>
                            <tr>
                                <td><a id="btn0" href="#" class="btn btn-block btn-lg btn-inverse">0</a></td>
                                <td colspan="2"><a id="btnClear" href="#" class="btn btn-block btn-lg btn-default text-uppercase">Clear</a></td>

                            </tr>
                        </table>
                    </div><!-- // Pin Pad -->

                    <div id="confirmPin">
                        <button name="confirmPin" class="confirm btn btn-block btn-lg btn-success text-uppercase">Confirm</button>
                    </div>
                    <div class="demo-type-example">
                        <?php 
                          if(isset($_SESSION['pinError'])){
                              echo "<h5>".$_SESSION['pinError']."</h5>";
                              unset($_SESSION['pinError']);
                          } 
                        ?>
                    </div>
                    <div id="cancelTransaction">
                        <a href="function.php?logout=true" class="btn btn-block btn-lg btn-danger text-uppercase"><span class="fui-cross"></span> Cancel</a>
                    </div><!-- // Pin Pad -->
                </form>
            </div>


        </div><!-- // END login screen  -->
    </div><!--  // END column-->

</div><!-- // END row-->
</div> <!-- /container -->
<?php include('footer.php')?>