
document.getElementById("btnClear").addEventListener("click", function () {
    document.getElementById("userPinInput").value = "";
});
function qc1k(){
    document.getElementById("qcCustomNumber").value = "1000";
}
function qc2k() {
    document.getElementById("qcCustomNumber").value = "2000";
}
function qc5k() {
    document.getElementById("qcCustomNumber").value = "5000";
}
function qc10k() {
    document.getElementById("qcCustomNumber").value = "10000";
}
function qc20k() {
    document.getElementById("qcCustomNumber").value = "20000";
}
function qc25k() {
    document.getElementById("qcCustomNumber").value = "25000";
}
function qc1k() {
    document.getElementById("qcCustomNumber").value = "1000";
}
function dlt() {
    document.getElementById("qcCustomNumber").value = "";
}

document.getElementById("btnDelete").addEventListener("click", function () {
    document.getElementById("qcCustomNumber").value = "0";
});