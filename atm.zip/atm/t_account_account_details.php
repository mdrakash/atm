<?php 
  include('header.php');
  if(isset($_SESSION['card_no'])){
      $card_no=$_SESSION['card_no'];
      $sql = "SELECT * FROM user where card_no='$card_no'";
      $connection = db_config::DBConnect();
      $resource_data = $connection->view($sql);
      $resource_obj = $resource_data->fetch_object();
      $accname=$resource_obj->name;
      $bal=$resource_obj->balance;
    }
?>
<div class="row">
    <div class="col-xs-12" id="screenView">
        <!-- Place <h1></h1> below -->
        <h1 class="demo-section-title text-uppercase text-center">Account Details</h1>
        <h6 class="text-uppercase text-center"><?php echo $accname?></h6>
        <br />
        <div class="row">

            <!-- 3/4 -->
            <!-- Balance -->
            <div class="col-xs-9">
                <div class="col-xs-12">
                    <div class="tile">
                        <h4 class="text-uppercase balance"><span>Balance</span><?php echo $bal?></h4>
                    </div>
                </div>
                <!-- Options -->
                <div class="col-xs-4">
                    <div class="tile">
                        <a href="t_account_deposit.php">
                            <img src="img/deposit_vault.png" alt="Make a Deposit" class="tile-image big-illustration">
                            <h3 class="tile-title">Deposit</h3>
                            <p>Deposit monies in form of cash or check.</p>
                        </a>
                    </div>
                </div>

                <div class="col-xs-4">
                    <a href="t_account_withdrawl.php">
                        <div class="tile">
                            <img src="img/quick_cash.png" alt="Withdraw Funds" class="tile-image">
                            <h3 class="tile-title">Withdrawl</h3>
                            <p>Withdraw funds from account.</p>
                        </div>
                    </a>
                </div>

                <div class="col-xs-4">
                    <a href="t_account_transfer_funds.php">
                        <div class="tile">
                            <img src="img/transfer_money.png" alt="Transfer Funds to Another Account" class="tile-image">
                            <h3 class="tile-title">Transfer</h3>
                            <p>Transfer funds to another account.</p>
                        </div>
                    </a>
                </div><!-- // END OPTIONS -->
            </div>
            <!-- 1/4 -->
            <div class="col-xs-3">

                <div class="tile">
                    <a id="logout" href="function.php?logout=true" class="btn btn-lg btn-info text-uppercase btn-padding"><span class="fui-user"></span> Logout</a>
                </div>
            </div>
        </div> <!-- // END OPTIONS-->
    </div><!--  // END column-->
</div><!-- // END row-->
</div> <!-- /container -->
<?php include('footer.php')?>