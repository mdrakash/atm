<?php 
  include('header.php');
  if(isset($_SESSION['card_no'])){
      $card_no=$_SESSION['card_no'];
      $sql = "SELECT * FROM user where card_no='$card_no'";
      $connection = db_config::DBConnect();
      $resource_data = $connection->view($sql);
      $resource_obj = $resource_data->fetch_object();
      $card_no=$resource_obj->card_no;
    }
?>
<div class="row">
    <div class="col-xs-12" id="screenView">
        <!-- Place <h1></h1> below -->
        <h1 class="demo-section-title text-uppercase text-center">Transfer Funds</h1>

        <div class="row">

            <!-- 3/4 -->
            <!-- Balance -->
            <div class="col-xs-9">
                <form action="function.php" method="post">
                    <div class="col-xs-12">
                        <blockquote>Transfer funds from one account to another. You can type in a routing number of another account that is not in your available accounts. </blockquote>
                    </div>
                    <!-- Options -->
                    <div class="col-xs-6">
                        <div class="tile">
                            <h5>From:</h5>
                            <input name="accfrom" class="btn btn-block btn-lg btn-inverse" value="<?php echo $card_no?>">
                        </div>
                    </div>

                    <div class="col-xs-6">
                        <div class="tile">
                            <h5>To:</h5>
                            <input name="accto" class="text-center btn-block btn-lg btn-inverse">
                        </div>
                    </div>
                    <div class="col-xs-12">
                        <div class="tile">
                            <h5>Ammount:</h5>
                            <input name="ammount" class="text-center btn-block btn-lg btn-inverse">
                            <?php 
                        if(isset($_SESSION['low'])){
                          echo "<h4 class='text-danger text-uppercase'>".$_SESSION['low']."</h4>";
                          unset($_SESSION['low']);
                        } 
                      ?>
                            <?php 
                        if(isset($_SESSION['Invalid'])){
                          echo "<h4 class='text-danger text-uppercase'>".$_SESSION['Invalid']."</h4>";
                          unset($_SESSION['Invalid']);
                        } 
                      ?>
                        </div>
                    </div>
                    <!-- // END OPTIONS -->

                    <div class="col-xs-12" style="margin-bottom: 2rem;">
                        <button name="transfer" class="btn btn-block btn-lg btn-success">
                            <h6><span class="fui-check"></span> Confirm Transfer</h6>
                        </button>
                    </div>
                </form>
            </div>
            <!-- 1/4 -->
            <div class="col-xs-3">
                <div class="tile">
                    <a id="back" href="t_account_account_details.php" class="btn btn-lg btn-inverse text-uppercase btn-padding"><span class="fui-arrow-left"></span> Back</a>
                </div>
                <div class="tile">
                    <a id="logout" href="function.php?logout=true" class="btn btn-lg btn-info text-uppercase btn-padding"><span class="fui-user"></span> Logout</a>
                </div>
                <div class="tile">
                    <a id="cancelTransactin" href="t_account_account_details.php" class="btn btn-lg btn-danger text-uppercase btn-padding"><span class="fui-cross"></span> Cancel</a>
                </div>
            </div>
        </div> <!-- // END OPTIONS-->
    </div><!--  // END column-->
</div><!-- // END row-->
</div> <!-- /container -->
<?php include('footer.php')?>