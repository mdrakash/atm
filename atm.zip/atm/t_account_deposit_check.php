<?php 
  include('header.php');
  if(isset($_SESSION['card_no'])){
      $card_no=$_SESSION['card_no'];
      $sql = "SELECT * FROM user where card_no='$card_no'";
      $connection = db_config::DBConnect();
      $resource_data = $connection->view($sql);
      $resource_obj = $resource_data->fetch_object();
      $accname=$resource_obj->name;
      $bal=$resource_obj->balance;
      $check=50000*rand(1,10);
    }             
?>
<div class="row">

    <div class="col-xs-12" id="screenView">
        <!-- Place <h1></h1> below -->
        <h1 class="demo-section-title text-uppercase text-center">Deposit Check</h1>
        <h6 class="text-uppercase text-center"><?php echo $accname?></h6>
        <br />
        <div class="row">

            <!-- 3/4 -->
            <!-- Balance -->
            <div class="col-xs-9">

                <div class="col-xs-6">

                    <blockquote>Insert check into slot labeled "Insert Check" when light turns green. Click <strong>DONE</strong> to complete transaction.</blockquote>

                    <div class="tile">
                        <h4 class="text-uppercase">
                            <div class="palette-clouds">Balance</div><?php echo $bal;?>
                        </h4>
                    </div>



                    <div class="tile">
                        <?php 
                        if(isset($_SESSION['insert'])){
                          echo "<h4 class='text-danger text-uppercase'>".$_SESSION['insert']."</h4>";
                          unset($_SESSION['insert']);
                        } 
                      ?>
                        <h4 class="text-uppercase">
                            <div class="palette-clouds">Check(s) Total</div><?php echo $check?>
                        </h4>
                    </div>
                    <a id="done" href="function.php?cash=<?php echo $check?>" class="btn btn-lg btn-success text-uppercase btn-padding" style="width:100%; margin-bottom:1rem;"><span class="fui-check"></span> Done</a>
                </div>

                <div class="col-xs-6" style="border:solid 1px #CCC; border-top:none; border-bottom:none;">
                    <img src="img/InsertCheckAnimations.gif" style="width:18em;" />
                </div>

            </div>
            <!-- 1/4 -->
            <div class="col-xs-3">
                <div class="tile">
                    <a id="back" href="t_account_deposit.php" class="btn btn-lg btn-inverse text-uppercase btn-padding"><span class="fui-arrow-left"></span> Back</a>
                </div>
                <div class="tile">
                    <a id="logout" href="function.php?logout=true" class="btn btn-lg btn-info text-uppercase btn-padding"><span class="fui-user"></span> Logout</a>
                </div>
                <div class="tile">
                    <a id="cancelTransactin" href="t_account_account_details.php" class="btn btn-lg btn-danger text-uppercase btn-padding"><span class="fui-cross"></span> Cancel</a>
                </div>
            </div>
        </div> <!-- // END OPTIONS-->


    </div><!--  // END column-->

</div><!-- // END row-->

</div> <!-- /container -->
<?php include('footer.php')?>