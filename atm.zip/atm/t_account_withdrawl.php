<?php 
  include('header.php');
  if(isset($_SESSION['card_no'])){
      $card_no=$_SESSION['card_no'];
      $sql = "SELECT * FROM user where card_no='$card_no'";
      $connection = db_config::DBConnect();
      $resource_data = $connection->view($sql);
      $resource_obj = $resource_data->fetch_object();
      $accname=$resource_obj->name;
    }
?>
<div class="row">
    <div class="col-xs-12" id="screenView">
        <!-- Place <h1></h1> below -->
        <h1 class="demo-section-title text-uppercase text-center">Withdrawal Funds</h1>
        <h6 class="text-uppercase text-center"><?php echo $accname?></h6>

        <div class="row">

            <!-- 3/4 -->
            <div class="col-xs-9">
                <div class="row">
                    <div class="col-xs-4">
                        <div class="tile">
                            <a id="qc1k" onclick="qc1k()" href="#" class="btn btn-lg btn-primary text-uppercase btn-padding">1000</a>
                        </div>

                        <div class="tile">
                            <a id="qc2k" onclick="qc2k()" href="#" class="btn btn-lg btn-primary text-uppercase btn-padding">2000</a>
                        </div>

                    </div>
                    <div class="col-xs-4">
                        <div class="tile">
                            <a id="qc5k" onclick="qc5k()" href="#" class="btn btn-lg btn-primary text-uppercase btn-padding">5000</a>
                        </div>

                        <div class="tile">
                            <a id="qc10k" onclick="qc10k()" href="#" class="btn btn-lg btn-primary text-uppercase btn-padding">10000</a>
                        </div>
                    </div>

                    <div class="col-xs-4">
                        <div class="tile">
                            <a id="qc20k" onclick="qc20k()" href="#" class="btn btn-lg btn-primary text-uppercase btn-padding">20000</a>
                        </div>

                        <div class="tile">
                            <a id="qc25k" href="#" onclick="qc25k()" class="btn btn-lg btn-primary text-uppercase btn-padding">25000</a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <h6>Click a button to get that amount of cash.</h6>
                        <h5>or input a multiple of 5. Must be lower than 500</h5>
                        <?php 
                    if(isset($_SESSION['lowbal'])){
                      echo "<h4 class='text-danger text-uppercase'>".$_SESSION['lowbal']."</h4>";
                      unset($_SESSION['lowbal']);
                  } 
                  ?>
                        <form action="function.php" method="post">
                            <input type="text" name="with" value="" id="qcCustomNumber" class="form-control" />


                            <!-- Number Keys -->

                            <!-- TABLE -->
                            <div id="pinPad">
                                <table>
                                    <tr>
                                        <td><a id="btn1" href="#" class="btn btn-block btn-lg btn-inverse">1</a></td>
                                        <td><a id="btn2" href="#" class="btn btn-block btn-lg btn-inverse">2</a></td>
                                        <td><a id="btn3" href="#" class="btn btn-block btn-lg btn-inverse">3</a></td>
                                        <td><a id="btn4" href="#" class="btn btn-block btn-lg btn-inverse">4</a></td>
                                        <td><a id="btn5" href="#" class="btn btn-block btn-lg btn-inverse">5</a></td>
                                        <td colspan="2"><button id="btnConfirm" name="withdraw" class="btn btn-lg btn-primary text-uppercase">Confirm</button></td>
                                    </tr>
                                    <tr>
                                        <td><a id="btn6" href="#" class="btn btn-block btn-lg btn-inverse">6</a></td>
                                        <td><a id="btn7" href="#" class="btn btn-block btn-lg btn-inverse">7</a></td>
                                        <td><a id="btn8" href="#" class="btn btn-block btn-lg btn-inverse">8</a></td>
                                        <td><a id="btn9" href="#" class="btn btn-block btn-lg btn-inverse">9</a></td>
                                        <td><a id="btn0" href="#" class="btn btn-block btn-lg btn-inverse">0</a></td>
                                        <td colspan="2"><a id="btnDelete" onclick="dlt()" href="#" class="btn btn-block btn-lg btn-default text-uppercase">Clear</a></td>
                                    </tr>
                                </table>
                        </form>
                    </div><!-- // Pin Pad -->

                </div>
            </div>

        </div>
        <!-- 1/4 -->
        <div class="col-xs-3">

            <div class="tile">
                <a id="logout" href="function.php?logout=true" class="btn btn-lg btn-info text-uppercase btn-padding"><span class="fui-user"></span> Logout</a>
            </div>
            <div class="tile">
                <a id="cancelTransactin" href="t_account_account_details.php" class="btn btn-lg btn-danger text-uppercase btn-padding"><span class="fui-cross"></span> Cancel</a>
            </div>
        </div>




    </div> <!-- // END OPTIONS-->


</div><!--  // END column-->

</div><!-- // END row-->
</div> <!-- /container -->
<?php include('footer.php')?>