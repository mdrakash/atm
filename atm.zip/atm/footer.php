        <script src="js/index.js"></script>
        <script src="js/jquery.min.js"></script>
        <script src="js/flat-ui.min.js"></script>
        <script src="js/application.js"></script>
    </body>
</html>