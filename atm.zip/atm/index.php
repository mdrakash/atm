<?php 
    include('db_config.php');
     session_start();
    // if(isset($_SESSION['login'])){
    //     echo $_SESSION['login'];
    //}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>ATM System Login: Insert Card</title>
    <meta name="description" content="Flat UI Kit Free is a Twitter Bootstrap Framework design and Theme, this responsive framework includes a PSD and HTML version."/>

    <meta name="viewport" content="width=1000, initial-scale=1.0, maximum-scale=1.0">

    <!-- Loading Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Loading Flat UI -->
    <link href="css/flat-ui.css" rel="stylesheet">
    <link href="css/demo.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <link rel="shortcut icon" href="img/favicon.ico">
  </head>
  <body>
    <div class="container">
      <div class="demo-headline" style="padding:0px;">
        <h1 class="demo-logo">ATM
          <small>24 Hour Banking</small>
        </h1>
      </div> <!-- /demo-headline -->
<div class="row">
    <div class="col-xs-12" id="screenView">
        <!-- Place <h1></h1> below -->

        <!-- Replace Video with Animated Gif or Animated SVG -->
        <div class="row">
            <div class="col-md-6 text-center">
                <h1 class="demo-section-title text-uppercase text-center">Insert Card to Begin</h1>
                <img src="img/InsertCardAnimate.gif" />

            </div> <!-- // ANIMATED GIF -->
            <div class="col-md-2 text-center">
                <h4 style="margin-top: 90%;">OR</h4>

            </div> <!-- // ANIMATED GIF -->

            <div class="col-md-4">
                <br />
                <h1 class="demo-section-title text-uppercase text-center">Insert Card Number</h1>
                <div class="form-group">
                    <form action="function.php" method="post">
                        <input type="text" value="" name="card_no" placeholder="Card Number" autocomplete="off" class="form-control" />
                        <button name="enter_card" class="enter_card card_login btn btn-primary">Enter</button>
                    </form>
                    <?php 
                      if(isset($_SESSION['cardError'])){
                          echo "<h4 class='text-danger'>".$_SESSION['cardError']."</h4>";
                          unset($_SESSION['cardError']);
                      } 
                    ?>
                </div>

            </div><!-- /.col-xs-4 -->
        </div><!-- // END login screen  -->
    </div><!--  // END column-->

</div><!-- // END row-->
</div> <!-- /container -->
<?php include('footer.php')?>